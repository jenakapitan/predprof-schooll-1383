#ifndef WEBSERVER_ESP_H
#define WEBSERVER_ESP_H

#include <Arduino.h>

void startServer();
String waitForCommand();

#endif